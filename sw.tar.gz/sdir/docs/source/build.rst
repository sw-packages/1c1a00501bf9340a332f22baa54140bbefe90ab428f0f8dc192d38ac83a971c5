build
=====

sol3 is a header-only library.

sol3 comes with a CMake script in the top level. It is primarily made for building and running the examples and tests, but it includes exported and configured targets (``sol2``, ``sol2_single``) for your use.

sol3 also comes with a Meson Script. If things stop working, file a bug report.


