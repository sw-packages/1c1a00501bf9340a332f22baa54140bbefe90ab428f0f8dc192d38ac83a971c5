name = "Asus"
width = 1920
height = 1080
